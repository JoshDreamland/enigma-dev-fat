# This script is to be run from the trunk
# or other toplevel directory.

# Get the revision number
rev=`svn info | grep -i -o -m 1 "rev\(ision\)\?: [0-9]\+"`
rev=`echo "$rev" | grep -o "[0-9]\+"`

echo "Prepare install-ready zip for revision $rev"

# Create the directory
odir=ENIGMA-R4-r$rev
if mkdir -p $odir;
then
	echo "Made directory for output"
else
	echo "Failed to create directory!"
	exit 1
fi

# Copy shit into it
cp ./CompilerSource/stupidity-buffer/ENIGMA.exe $odir/
cp ./l*.jar $odir/
cp -r ./plugins $odir/
cp -r ./Autoconf $odir/
mv $odir/Autoconf/svnkit.jar $odir/plugins/shared/
mkdir $odir/Compilers
mkdir $odir/Compilers/Windows

# Enter our directory for sprucing and trimming
cd $odir

# Remove SVN files
svns=`find ./ -regex ".*/\.svn" -exec rm -rf {} \;`

# Zip the directory
cd ../
rm -f odir.zip
zip -r $odir.zip $odir 

rm -rf $odir
