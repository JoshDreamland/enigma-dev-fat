# Prepare a release ZIP for Windows.
# Run this file from the trunk or the appropriate tag!
if test "$1" == ""
then
  path="ENIGMA.zip"
else
  path=$1
fi
rm $path
mkdir /tmp/ENIGMA
  cp CompilerSource/stupidity-buffer/ENIGMA.exe /tmp/ENIGMA
  cp l*.jar /tmp/ENIGMA
  mkdir /tmp/ENIGMA/plugins
    cp plugins/* /tmp/ENIGMA/plugins
    mkdir /tmp/ENIGMA/plugins/shared
      cp plugins/shared/* /tmp/ENIGMA/plugins/shared
      cp Autoconf/svnkit.jar /tmp/ENIGMA/plugins/shared
  mkdir /tmp/ENIGMA/Autoconf
  cp Autoconf/* /tmp/ENIGMA/Autoconf
echo zip -r $path "/tmp/ENIGMA"
zip -r $path "/tmp/ENIGMA"
rm -rf /tmp/ENIGMA/
rmdir /tmp/ENIGMA
